import * as usuarioModel from "../sprites/usuario.sprite.js";
import crypto from "crypto";

export async function listar(req,res){
    const usuario = await usuarioModel.listarUsuario();
    res.status(200).json(usuario);
}

export async function buscarPorId(req,res) {
    const id = req.params.id;
    const usuario = await usuarioModel.buscarUsuarioPorId(id);

    if(!usuario){
        return res.status(404).json({msg:"Usuário não encontrado"})
    }

    res.status(200).json(usuario);
   
}

export async function criar(req,res){
    const {nome,email,senha} = req.body;

    if(!nome || !email || !senha){
        return res.status(404).json({msg:"Nome, email, e senha é obrigatório"})
    }

    const senha_hash = crypto 
    .createHash("sha256")
    .update(senha)
    .digest("hex");
    
    const id = await usuarioModel.criarUsuario(
        {nome,email,senha_hash}
    )

    return res.status(201).json({msg:"Usuario criado com sucesso"})
}

export async function login(req,res){
    const {email, senha} = req.body;
    if(!email || !senha) {
        return res.status(400).json({msg:"Email e senha é necessario"})
    }

    const usuario = await usuarioModel.buscarUsuarioPorEmail(email);
    if(!usuario){
        return res.status(401).json({msg:"Credenciais invalidas"})
    }

    const senha_hash = crypto 
    .createHash("sha256")
    .update(senha)
    .digest("hex");
    if(senha_hash !== usuario.senha_hash){
        return res.status(401).json({msg:"Credenciais invalidas"})
    }

    const token = crypto.randomBytes(24).toString("hex");

    return res.status(200).json({
        msg:"login realizado com sucesso",
        token,
        usuario :{
            id:usuario.id,
            email: usuario.email,
            nome:usuario.nome
        }
    })
}
