import express from "express";
import usuarioRoutes from "./routes/usuario.routs.js";
import cors from "cors";

const app = express();
app.use(express.json());

app.use(cors())

app.use("/usuarios", usuarioRoutes);

// app.use("/jogos", jogoRoutes);
// app.use("/players", playersRoutes);
// app.use("/jogpartidasos", partidasRoutes);

export default app;