import {Router} from "express";
import * as usuarioController from "../controller/controller.js";


const router = Router();

router.get("/login",usuarioController.login);

router.get("/",usuarioController.listar);
router.get("/:id",usuarioController.buscarPorId);
router.post("/",usuarioController.criar);


export default router;

