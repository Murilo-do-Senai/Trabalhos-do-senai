const numero = document.getElementById("Num");
const num1 = 10;
const num2 = 20;
const num3 = 30;
const val = num1 + num2 + num3 /2;

numero.innerHTML = `${val}`;
let confere = false;
const azul =rgb(0, 195, 255) ;
const vermelho = rgb(255, 0, 0);
const branco = rgb(225, 225, 225);
numero.style.backgroundColor=`${branco}`;

numero.addEventListener("click",()=>{
    if(num1,num2,num3 < 50%val){
        numero.style.backgroundColor=`${vermelho}`;
        confere = true;
    }else {
        numero.style.backgroundColor=`${azul}`;
        confere = false;
    }
});