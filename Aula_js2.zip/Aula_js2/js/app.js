import { Pessoa } from "./class/Pessoas.js";
const nome = document.getElementById("txtNome");
const botao = document.getElementById("btnBotao");
const r = document.getElementById("resp");
botao.addEventListener("click",function(){
    const nomePessoa = nome.value;
    const pessoa = new Pessoa(nomePessoa);
    r.innerHTML = `Olá ${pessoa.nome} com o valor click`
});
botao.addEventListener("mouseover",function(){
    const nomePessoa = nome.value;
    const pessoa = new Pessoa(nomePessoa);
r.innerHTML = `Olá ${pessoa.nome} com o valor focus`
});