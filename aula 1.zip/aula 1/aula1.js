const express = require('express');
const app = express();
const PORTA = 3001;

app.use(express.json());

function calcularIdade(dataNascimento) {
    const hoje = new Date();
    const nascimento = new Date(dataNascimento);

    let idade = hoje.getFullYear() - nascimento.getFullYear();

    const mes = hoje.getMonth() - nascimento.getMonth();

    if(mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())){
        idade--;
    }
    return idade;
}

function validarCPF(cpf){
   
    const cpflimpo = cpf.replace(/[^\d]/g,"");
    

    if(cpflimpo.length !== 11){
        return false;
    }

    if (calculaDigito(10,cpflimpo)!==parseInt(cpflimpo.charAt(9))){
        return false;
    }
    if (calculaDigito(11,cpflimpo)!==parseInt(cpflimpo.charAt(10))){
        return false;
    }
    return true;

    }
    function calculaDigito(posicao,cpflimpo){
    let soma = 0;
    for(let i=0;i<posicao-1;i++){
        soma += parseInt(cpflimpo.charAt(i) * (posicao-i));
    }

        let resto = (soma*10)%11;
        if (resto===10 || resto===11){
            resto = 0;
        }
        
    }

    app.post('/analisar', (req,res) =>{
        const { nome, cpf, dataNascimento} = req.body;

        if (!nome || !cpf || !dataNascimento) {
            return res.status(400).json({erro: "Nome, CPF e data de nascimento são obrigatorios."});
        }

        const idade = calcularIdade(dataNascimento);
        const cpfvalido = validarCPF(cpf);

        return res.json({
            nome,
            idade,
            cpf,
            CPF_Vaido: cpfvalido ? "CPF Valido!✅" : "CPF Invalido!🚫",
            situacao: idade >= 18 ? "Maior idade!✅" : "Menor de idade!🔞"

        });
    });

    app.listen(PORTA, () => {
        console.log(`Servidor rodando em http://localhost:${PORTA}`);
    });






